package com.raylan.grxlento;

interface IShellService {
    String execCommand(String command) = 1;
    void destroy() = 16777114;
}
