package com.raylan.grxlento.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.raylan.grxlento.MainActivity
import com.raylan.grxlento.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class GrxOverlayService : Service() {

    companion object {
        const val ACTION_START = "com.raylan.grxlento.overlay.START"
        const val ACTION_STOP = "com.raylan.grxlento.overlay.STOP"
        const val ACTION_UPDATE_STYLE = "com.raylan.grxlento.overlay.UPDATE_STYLE"
        const val EXTRA_STYLE = "extra_crosshair_style"

        private const val CHANNEL_ID = "grx_overlay_channel"
        private const val NOTIFICATION_ID = 7701

        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

        private val _currentStyle = MutableStateFlow(CrosshairStyle.VERTICAL_GUIDE)
        val currentStyle: StateFlow<CrosshairStyle> = _currentStyle.asStateFlow()

        fun startOverlay(context: Context, style: CrosshairStyle) {
            runCatching {
                if (!Settings.canDrawOverlays(context)) return
                val intent = Intent(context, GrxOverlayService::class.java).apply {
                    action = ACTION_START
                    putExtra(EXTRA_STYLE, style.name)
                }
                context.startForegroundService(intent)
            }
        }

        fun updateStyle(context: Context, style: CrosshairStyle) {
            _currentStyle.value = style
            if (!_isRunning.value) return
            runCatching {
                val intent = Intent(context, GrxOverlayService::class.java).apply {
                    action = ACTION_UPDATE_STYLE
                    putExtra(EXTRA_STYLE, style.name)
                }
                context.startService(intent)
            }
        }

        fun stopOverlay(context: Context) {
            runCatching {
                val intent = Intent(context, GrxOverlayService::class.java).apply {
                    action = ACTION_STOP
                }
                context.startService(intent)
            }
        }
    }

    private var windowManager: WindowManager? = null
    private var overlayView: CrosshairOverlayView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = runCatching {
            getSystemService(WINDOW_SERVICE) as? WindowManager
        }.getOrNull()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        val styleExtra = intent?.getStringExtra(EXTRA_STYLE)
        if (styleExtra != null) {
            runCatching { CrosshairStyle.valueOf(styleExtra) }
                .onSuccess { _currentStyle.value = it }
        }

        when (action) {
            ACTION_STOP -> {
                removeOverlayView()
                _isRunning.value = false
                runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
                stopSelf()
                return START_NOT_STICKY
            }

            ACTION_UPDATE_STYLE -> {
                overlayView?.updateStyle(_currentStyle.value)
                return START_STICKY
            }

            else -> {
                ensureForegroundNotification()
                if (!Settings.canDrawOverlays(this)) {
                    _isRunning.value = false
                    stopSelf()
                    return START_NOT_STICKY
                }
                showOrUpdateOverlayView()
                return START_STICKY
            }
        }
    }

    override fun onDestroy() {
        removeOverlayView()
        _isRunning.value = false
        super.onDestroy()
    }

    private fun ensureForegroundNotification() {
        runCatching {
            val manager = getSystemService(NotificationManager::class.java)
            if (manager != null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.overlay_notification_channel),
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    setShowBadge(false)
                }
                manager.createNotificationChannel(channel)
            }

            val openAppIntent = PendingIntent.getActivity(
                this,
                0,
                Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            val notification = Notification.Builder(this, CHANNEL_ID)
                .setContentTitle(getString(R.string.overlay_notification_title))
                .setContentText(getString(R.string.overlay_notification_text))
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentIntent(openAppIntent)
                .setOngoing(true)
                .build()

            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun showOrUpdateOverlayView() {
        val wm = windowManager ?: return
        if (overlayView != null) {
            overlayView?.updateStyle(_currentStyle.value)
            _isRunning.value = true
            return
        }

        runCatching {
            val density = resources.displayMetrics.density
            val widthPx = (140 * density).toInt()
            val heightPx = (200 * density).toInt()

            val params = WindowManager.LayoutParams(
                widthPx,
                heightPx,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.CENTER
            }

            val view = CrosshairOverlayView(this).apply {
                updateStyle(_currentStyle.value)
            }
            wm.addView(view, params)
            overlayView = view
            _isRunning.value = true
        }.onFailure {
            _isRunning.value = false
        }
    }

    private fun removeOverlayView() {
        runCatching {
            val view = overlayView ?: return
            windowManager?.removeViewImmediate(view)
        }
        overlayView = null
    }
}

private class CrosshairOverlayView(context: Context) : View(context) {

    private var style: CrosshairStyle = CrosshairStyle.VERTICAL_GUIDE

    private val cyanPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E5FF")
        strokeWidth = 3.5f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val orangePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF6B00")
        strokeWidth = 3.5f
        style = Paint.Style.FILL
    }

    private val glowOutlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#9907080D")
        strokeWidth = 6.5f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    fun updateStyle(newStyle: CrosshairStyle) {
        style = newStyle
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val density = resources.displayMetrics.density

        when (style) {
            CrosshairStyle.VERTICAL_GUIDE -> {
                val topY = cy - 64f * density
                val bottomY = cy + 44f * density
                val tickHalf = 8f * density

                // Guia vertical principal com contorno para alta visibilidade
                canvas.drawLine(cx, topY, cx, bottomY, glowOutlinePaint)
                canvas.drawLine(cx, topY, cx, bottomY, cyanPaint)

                // Marcações de puxada vertical
                for (offset in listOf(-46f, -24f, 24f)) {
                    val ty = cy + offset * density
                    canvas.drawLine(cx - tickHalf, ty, cx + tickHalf, ty, glowOutlinePaint)
                    canvas.drawLine(cx - tickHalf, ty, cx + tickHalf, ty, cyanPaint)
                }

                // Seta superior em Laranja Fogo para referência de subida
                canvas.drawLine(cx, topY, cx - 7f * density, topY + 9f * density, orangePaint.apply {
                    style = Paint.Style.STROKE
                })
                canvas.drawLine(cx, topY, cx + 7f * density, topY + 9f * density, orangePaint)
                orangePaint.style = Paint.Style.FILL

                // Ponto central
                canvas.drawCircle(cx, cy, 4.2f * density, orangePaint)
            }

            CrosshairStyle.PRO_RING -> {
                val radius = 18f * density
                val gap = 10f * density
                val arm = 10f * density

                canvas.drawCircle(cx, cy, radius, glowOutlinePaint)
                canvas.drawCircle(cx, cy, radius, cyanPaint)

                // 4 hastes táticas
                canvas.drawLine(cx - radius - arm, cy, cx - gap, cy, cyanPaint)
                canvas.drawLine(cx + gap, cy, cx + radius + arm, cy, cyanPaint)
                canvas.drawLine(cx, cy - radius - arm, cx, cy - gap, cyanPaint)
                canvas.drawLine(cx, cy + gap, cx, cy + radius + arm, cyanPaint)

                canvas.drawCircle(cx, cy, 3.2f * density, orangePaint)
            }

            CrosshairStyle.CENTER_DOT -> {
                canvas.drawCircle(cx, cy, 5.5f * density, glowOutlinePaint)
                canvas.drawCircle(cx, cy, 4.0f * density, cyanPaint.apply { style = Paint.Style.FILL })
                cyanPaint.style = Paint.Style.STROKE
                canvas.drawCircle(cx, cy, 2.0f * density, orangePaint)
            }
        }
    }
}
