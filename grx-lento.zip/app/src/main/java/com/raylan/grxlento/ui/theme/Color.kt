package com.raylan.grxlento.ui.theme

import androidx.compose.ui.graphics.Color

val DeepBlack = Color(0xFF07080D)
val MetallicNavy = Color(0xFF10131F)
val MetallicNavyVariant = Color(0xFF171C2E)
val TerminalBlack = Color(0xFF040509)

val NeonCyan = Color(0xFF00E5FF)
val FireOrange = Color(0xFFFF6B00)
val NeonGreen = Color(0xFF00E676)
val CriticalRed = Color(0xFFFF1744)

val TextPrimary = Color(0xFFF4F7FF)
val TextSecondary = Color(0xFF9AA8C7)
val BorderSubtle = Color(0xFF1F2A44)
