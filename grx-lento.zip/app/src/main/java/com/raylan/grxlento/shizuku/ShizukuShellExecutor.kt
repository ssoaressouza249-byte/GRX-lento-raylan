package com.raylan.grxlento.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import com.raylan.grxlento.BuildConfig
import com.raylan.grxlento.IShellService
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku

sealed class ShizukuConnectionState {
    data class Disconnected(val message: String) : ShizukuConnectionState()
    data class PermissionRequired(val message: String) : ShizukuConnectionState()
    data class Connecting(val message: String) : ShizukuConnectionState()
    data class Ready(val message: String) : ShizukuConnectionState()
    data class Error(val message: String) : ShizukuConnectionState()

    val isReady: Boolean
        get() = this is Ready
}

data class ShellExecutionResult(
    val success: Boolean,
    val exitCode: Int,
    val output: String
)

class ShizukuShellExecutor(private val context: Context) {

    companion object {
        private const val SHIZUKU_PERMISSION_REQUEST_CODE = 9001
    }

    private val appContext = context.applicationContext
    private val bindMutex = Mutex()

    private val _connectionState = MutableStateFlow<ShizukuConnectionState>(
        ShizukuConnectionState.Disconnected("Verificando Shizuku...")
    )
    val connectionState: StateFlow<ShizukuConnectionState> = _connectionState.asStateFlow()

    @Volatile
    private var shellService: IShellService? = null

    @Volatile
    private var pendingBindDeferred: CompletableDeferred<IShellService?>? = null

    private var listenersRegistered = false

    private val userServiceArgs: Shizuku.UserServiceArgs by lazy {
        Shizuku.UserServiceArgs(
            ComponentName(appContext.packageName, ShellServiceImpl::class.java.name)
        )
            .daemon(false)
            .processNameSuffix("grx_shell")
            .debuggable(BuildConfig.DEBUG)
            .version(BuildConfig.VERSION_CODE)
    }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            runCatching {
                val binderInterface = if (service != null && service.pingBinder()) {
                    IShellService.Stub.asInterface(service)
                } else {
                    null
                }
                shellService = binderInterface
                pendingBindDeferred?.complete(binderInterface)
                pendingBindDeferred = null
                if (binderInterface != null) {
                    _connectionState.value = ShizukuConnectionState.Ready("Shizuku AIDL Pronto")
                } else {
                    _connectionState.value = ShizukuConnectionState.Error("Binder nulo ao conectar")
                }
            }.onFailure {
                _connectionState.value = ShizukuConnectionState.Error("Falha ao conectar serviço AIDL")
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            shellService = null
            pendingBindDeferred?.complete(null)
            pendingBindDeferred = null
            refreshState()
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshState()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        shellService = null
        _connectionState.value = ShizukuConnectionState.Disconnected("Shizuku desconectado")
    }

    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == SHIZUKU_PERMISSION_REQUEST_CODE) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                _connectionState.value = ShizukuConnectionState.Connecting("Autorizado! Conectando AIDL...")
                bindUserServiceSafe()
            } else {
                _connectionState.value = ShizukuConnectionState.PermissionRequired("Permissão Shizuku negada")
            }
        }
    }

    fun start() {
        runCatching {
            if (!listenersRegistered) {
                Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
                Shizuku.addBinderDeadListener(binderDeadListener)
                Shizuku.addRequestPermissionResultListener(permissionResultListener)
                listenersRegistered = true
            }
        }
        refreshState()
    }

    fun release() {
        runCatching {
            if (listenersRegistered) {
                Shizuku.removeBinderReceivedListener(binderReceivedListener)
                Shizuku.removeBinderDeadListener(binderDeadListener)
                Shizuku.removeRequestPermissionResultListener(permissionResultListener)
                listenersRegistered = false
            }
        }
        runCatching {
            if (shellService != null) {
                Shizuku.unbindUserService(userServiceArgs, serviceConnection, true)
                shellService = null
            }
        }
    }

    fun refreshState() {
        runCatching {
            val binderAlive = Shizuku.pingBinder()
            if (!binderAlive) {
                shellService = null
                _connectionState.value = ShizukuConnectionState.Disconnected("Shizuku inativo ou fechado")
                return
            }

            if (Shizuku.isPreV11()) {
                _connectionState.value = ShizukuConnectionState.Error("Versão Shizuku incompatível")
                return
            }

            val granted = Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                _connectionState.value = ShizukuConnectionState.PermissionRequired("Autorização pendente")
                return
            }

            if (shellService?.asBinder()?.isBinderAlive == true) {
                _connectionState.value = ShizukuConnectionState.Ready("Shizuku AIDL Pronto")
            } else {
                _connectionState.value = ShizukuConnectionState.Connecting("Conectando serviço AIDL...")
                bindUserServiceSafe()
            }
        }.onFailure {
            _connectionState.value = ShizukuConnectionState.Disconnected("Shizuku indisponível no dispositivo")
        }
    }

    fun requestAuthorization(): String {
        return runCatching {
            if (!Shizuku.pingBinder()) {
                _connectionState.value = ShizukuConnectionState.Disconnected("Abra e inicie o app Shizuku primeiro")
                return "Shizuku não está em execução. Inicie o serviço Shizuku e tente novamente."
            }

            if (Shizuku.isPreV11()) {
                _connectionState.value = ShizukuConnectionState.Error("Versão Shizuku antiga (< v11)")
                return "Atualize o Shizuku para a versão 11 ou superior."
            }

            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                bindUserServiceSafe()
                return "Permissão Shizuku já concedida. Conectando AIDL..."
            }

            if (Shizuku.shouldShowRequestPermissionRationale()) {
                _connectionState.value = ShizukuConnectionState.PermissionRequired("Permita o acesso nas configurações do Shizuku")
            }

            Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
            "Solicitação de permissão enviada ao Shizuku."
        }.getOrElse { error ->
            _connectionState.value = ShizukuConnectionState.Disconnected("Shizuku não encontrado")
            "Não foi possível comunicar com o Shizuku: ${error.message ?: "serviço fechado"}"
        }
    }

    private fun bindUserServiceSafe() {
        runCatching {
            Shizuku.bindUserService(userServiceArgs, serviceConnection)
        }.onFailure { error ->
            _connectionState.value = ShizukuConnectionState.Error(
                "Erro ao iniciar UserService: ${error.message ?: "falha"}"
            )
        }
    }

    suspend fun execute(command: String): ShellExecutionResult = withContext(Dispatchers.IO) {
        val pingOk = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        if (!pingOk) {
            _connectionState.value = ShizukuConnectionState.Disconnected("Shizuku fechado ou inativo")
            return@withContext ShellExecutionResult(
                success = false,
                exitCode = -1,
                output = "[ERRO] Shizuku não está rodando. Abra o Shizuku e clique em 'Conectar Shizuku'."
            )
        }

        val permissionOk = runCatching {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)

        if (!permissionOk) {
            _connectionState.value = ShizukuConnectionState.PermissionRequired("Autorize o app no Shizuku")
            return@withContext ShellExecutionResult(
                success = false,
                exitCode = -1,
                output = "[PERMISSÃO] Autorização Shizuku necessária. Toque em 'Conectar Shizuku'."
            )
        }

        val service = ensureBoundService()
        if (service == null) {
            return@withContext ShellExecutionResult(
                success = false,
                exitCode = -1,
                output = "[AIDL] Serviço UserService ainda inicializando. Tente novamente em instantes."
            )
        }

        runCatching {
            val rawResponse = service.execCommand(command).orEmpty()
            val lines = rawResponse.lines()
            val firstLine = lines.firstOrNull().orEmpty()
            val exitCode = if (firstLine.startsWith("EXIT:")) {
                firstLine.removePrefix("EXIT:").toIntOrNull() ?: -1
            } else {
                0
            }
            val body = if (firstLine.startsWith("EXIT:")) {
                lines.drop(1).joinToString("\n").trim()
            } else {
                rawResponse.trim()
            }
            ShellExecutionResult(
                success = exitCode == 0,
                exitCode = exitCode,
                output = body.ifEmpty { "Comando concluído (exit=$exitCode)" }
            )
        }.getOrElse { error ->
            shellService = null
            refreshState()
            ShellExecutionResult(
                success = false,
                exitCode = -1,
                output = "[EXCEÇÃO AIDL] ${error.message ?: "Conexão interrompida"}"
            )
        }
    }

    private suspend fun ensureBoundService(): IShellService? {
        val current = shellService
        if (current != null && runCatching { current.asBinder().isBinderAlive }.getOrDefault(false)) {
            return current
        }

        return bindMutex.withLock {
            val recheck = shellService
            if (recheck != null && runCatching { recheck.asBinder().isBinderAlive }.getOrDefault(false)) {
                return@withLock recheck
            }

            val deferred = CompletableDeferred<IShellService?>()
            pendingBindDeferred = deferred
            bindUserServiceSafe()
            withTimeoutOrNull(3000L) {
                deferred.await()
            }
        }
    }
}
