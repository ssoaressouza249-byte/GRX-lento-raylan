package com.raylan.grxlento.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val GrxDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = DeepBlack,
    primaryContainer = MetallicNavyVariant,
    onPrimaryContainer = NeonCyan,
    secondary = FireOrange,
    onSecondary = DeepBlack,
    secondaryContainer = MetallicNavyVariant,
    onSecondaryContainer = FireOrange,
    tertiary = NeonGreen,
    onTertiary = DeepBlack,
    background = DeepBlack,
    onBackground = TextPrimary,
    surface = MetallicNavy,
    onSurface = TextPrimary,
    surfaceVariant = MetallicNavyVariant,
    onSurfaceVariant = TextSecondary,
    outline = NeonCyan,
    outlineVariant = BorderSubtle,
    error = CriticalRed,
    onError = TextPrimary
)

@Composable
fun GrxLentoTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GrxDarkColorScheme,
        typography = GrxTypography,
        content = content
    )
}
