package com.raylan.grxlento.ui

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.raylan.grxlento.overlay.CrosshairStyle
import com.raylan.grxlento.overlay.GrxOverlayService
import com.raylan.grxlento.shizuku.ShizukuConnectionState
import com.raylan.grxlento.shizuku.ShizukuShellExecutor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DeviceTelemetry(
    val freeRamMb: Long = 0L,
    val totalRamMb: Long = 0L,
    val batteryTempCelsius: Float = 0f,
    val lowMemory: Boolean = false
)

data class AiOptimizationReport(
    val timestamp: String,
    val freeRamBeforeMb: Long,
    val freeRamAfterMb: Long,
    val totalRamMb: Long,
    val batteryTempCelsius: Float,
    val thermalStatusText: String,
    val shizukuExecuted: Boolean,
    val summary: String
)

data class GrxUiState(
    val shizukuState: ShizukuConnectionState = ShizukuConnectionState.Disconnected("Verificando..."),
    val isBonecoLentoActive: Boolean = false,
    val isFangrxShotActive: Boolean = false,
    val isBonecoBusy: Boolean = false,
    val isFangrxBusy: Boolean = false,
    val isOverlayActive: Boolean = false,
    val hasOverlayPermission: Boolean = false,
    val selectedCrosshairStyle: CrosshairStyle = CrosshairStyle.VERTICAL_GUIDE,
    val bonecoBannerVisible: Boolean = false,
    val terminalLogs: List<String> = listOf(
        "[GRX] Painel pronto. Criador: Raylan.",
        "[SHIZUKU] Aguardando comando ou conexão AIDL..."
    ),
    val telemetry: DeviceTelemetry = DeviceTelemetry(),
    val isOptimizingAll: Boolean = false,
    val aiReport: AiOptimizationReport? = null
)

class GrxMainViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        private const val BONECO_LENTO_ON_CMD =
            "settings put secure long_press_timeout 120 && " +
                "settings put secure multi_press_timeout 120 && " +
                "settings put system pointer_speed 7 && " +
                "settings put global window_animation_scale 0.0 && " +
                "settings put global transition_animation_scale 0.0 && " +
                "settings put global animator_duration_scale 0.0 && " +
                "cmd power set-fixed-performance-mode-enabled true && " +
                "settings put global wifi_scan_always_enabled 0"

        private const val BONECO_LENTO_OFF_CMD =
            "settings put secure long_press_timeout 400 && " +
                "settings put secure multi_press_timeout 300 && " +
                "settings put system pointer_speed 0 && " +
                "settings put global window_animation_scale 1.0 && " +
                "settings put global transition_animation_scale 1.0 && " +
                "settings put global animator_duration_scale 1.0 && " +
                "cmd power set-fixed-performance-mode-enabled false && " +
                "settings put global wifi_scan_always_enabled 1"

        private const val FANGRXSHOT_ON_CMD =
            "settings put system pointer_speed 7 && " +
                "settings put system mouse_acceleration 0 && " +
                "settings put system hardware_acceleration true && " +
                "settings put global custom_pointer_speed_multiplier 100.0 && " +
                "settings put secure touch_h_scale 50.0 && " +
                "settings put secure touch_v_scale 42.0 && " +
                "settings put system touch_sensitivity 5.0 && " +
                "settings put system user_touch_response 1 && " +
                "setprop debug.input.velocitytracker.strategy baseline && " +
                "setprop touch.coverage.calibration box && " +
                "setprop touch.device.mode navigation && " +
                "settings put secure controller_y_axis_sensitivity 0.72 && " +
                "settings put global touch_distance_scale 0.0001 && " +
                "setprop touch_blocking_period 0.000001 && " +
                "settings put global touch_pixel_snapping 1 && " +
                "setprop debug.input.filter_noise false && " +
                "setprop aim_sensitivity_transition_time 0.00 && " +
                "setprop ro.input.no_hover 1 && " +
                "setprop debug.input.touch_jitter_filter false && " +
                "setprop ro.input.filter_touch_events 0 && " +
                "settings put global motion_prediction_enabled 1 && " +
                "setprop persist.device_config.motion_prediction.enable_prediction true && " +
                "settings put global view_touch_friction 0.0 && " +
                "setprop ro.tabs.default_friction 0 && " +
                "setprop debug.hwui.render_thread_policy 1 && " +
                "setprop debug.sf.early_phase_offset_ns 0 && " +
                "setprop persist.sys.use_fifo_ui 1 && " +
                "settings put system peak_refresh_rate 90.0 && " +
                "settings put system min_refresh_rate 90.0 && " +
                "setprop debug.hwui.renderer skiavk && " +
                "setprop debug.sf.latch_unsignaled true && " +
                "setprop persist.sys.input.boost 1 && " +
                "setprop debug.hwui.disabled_features 0 && " +
                "setprop persist.sys.game_mode 2 && " +
                "setprop debug.egl.force_vulkan 1 && " +
                "setprop debug.gr.vblank_disable true && " +
                "setprop debug.sf.disable_hwc_vblank 1 && " +
                "setprop debug.hwui.overdraw false && " +
                "setprop debug.sf.disable_client_composition_cache 1 && " +
                "setprop debug.unity.allow_low_latency 1 && " +
                "setprop debug.unity.gles3_only 1 && " +
                "setprop debug.sf.high_fps_late_app_phase_offset_ns 0 && " +
                "setprop persist.sys.game.perf_mode 1 && " +
                "setprop debug.hwui.skip_empty_shading_passes true && " +
                "settings put global view_scroll_friction 0.0 && " +
                "setprop debug.unity.allow_raw_input 1 && " +
                "settings put secure touch_accessibility_enhancement 1 && " +
                "cmd device_config put activity_manager max_phantom_processes 0 && " +
                "pm trim-caches 9999999999 && " +
                "am kill-all"

        private const val FANGRXSHOT_OFF_CMD =
            "settings put system pointer_speed 0 && " +
                "settings delete system peak_refresh_rate && " +
                "settings delete system min_refresh_rate && " +
                "settings put global view_touch_friction 0.015"

        private const val AI_TRIM_CACHE_CMD = "pm trim-caches 512M"
    }

    private val appContext = application.applicationContext
    private val shizukuExecutor = ShizukuShellExecutor(appContext)

    private val _uiState = MutableStateFlow(GrxUiState())
    val uiState: StateFlow<GrxUiState> = _uiState.asStateFlow()

    init {
        shizukuExecutor.start()
        refreshSystemStatus()

        viewModelScope.launch {
            combine(
                shizukuExecutor.connectionState,
                GrxOverlayService.isRunning,
                GrxOverlayService.currentStyle
            ) { shizukuState, overlayRunning, overlayStyle ->
                Triple(shizukuState, overlayRunning, overlayStyle)
            }.collect { (shizukuState, overlayRunning, overlayStyle) ->
                _uiState.update { state ->
                    state.copy(
                        shizukuState = shizukuState,
                        isOverlayActive = overlayRunning,
                        selectedCrosshairStyle = overlayStyle
                    )
                }
            }
        }
    }

    override fun onCleared() {
        shizukuExecutor.release()
        super.onCleared()
    }

    fun refreshSystemStatus() {
        val overlayPerm = runCatching { Settings.canDrawOverlays(appContext) }.getOrDefault(false)
        shizukuExecutor.refreshState()
        val telemetry = readDeviceTelemetry()
        _uiState.update {
            it.copy(
                hasOverlayPermission = overlayPerm,
                telemetry = telemetry
            )
        }
    }

    fun connectShizuku() {
        val statusMsg = shizukuExecutor.requestAuthorization()
        appendLog("[SHIZUKU] $statusMsg")
    }

    fun selectCrosshairStyle(style: CrosshairStyle) {
        GrxOverlayService.updateStyle(appContext, style)
        _uiState.update { it.copy(selectedCrosshairStyle = style) }
        appendLog("[MIRA] Estilo alterado para ${style.label}.")
    }

    fun toggleOverlayManually() {
        val canDraw = runCatching { Settings.canDrawOverlays(appContext) }.getOrDefault(false)
        _uiState.update { it.copy(hasOverlayPermission = canDraw) }
        if (!canDraw) {
            appendLog("[MIRA] Permissão de sobreposição necessária.")
            return
        }
        if (_uiState.value.isOverlayActive) {
            GrxOverlayService.stopOverlay(appContext)
            appendLog("[MIRA] Mira flutuante desativada.")
        } else {
            GrxOverlayService.startOverlay(appContext, _uiState.value.selectedCrosshairStyle)
            appendLog("[MIRA] Mira flutuante ativada (${_uiState.value.selectedCrosshairStyle.label}).")
        }
    }

    fun clearLogs() {
        _uiState.update {
            it.copy(terminalLogs = listOf("[GRX] Terminal limpo."))
        }
    }

    fun toggleBonecoLento(enable: Boolean) {
        if (_uiState.value.isBonecoBusy) return
        viewModelScope.launch {
            _uiState.update { it.copy(isBonecoBusy = true) }
            if (enable) {
                appendLog("[BONECO LENTO] Aplicando parâmetros táteis e performance...")
                val result = shizukuExecutor.execute(BONECO_LENTO_ON_CMD)
                appendLog("[BONECO LENTO] ${result.output}")

                val canDraw = runCatching { Settings.canDrawOverlays(appContext) }.getOrDefault(false)
                if (canDraw) {
                    GrxOverlayService.startOverlay(appContext, _uiState.value.selectedCrosshairStyle)
                    appendLog("[MIRA] Guia flutuante iniciada automaticamente.")
                } else {
                    appendLog("[MIRA] Sobreposição sem permissão — ative nas configurações.")
                }

                _uiState.update {
                    it.copy(
                        isBonecoLentoActive = true,
                        bonecoBannerVisible = true,
                        hasOverlayPermission = canDraw,
                        isBonecoBusy = false
                    )
                }
            } else {
                appendLog("[BONECO LENTO] Restaurando valores padrão do sistema...")
                val result = shizukuExecutor.execute(BONECO_LENTO_OFF_CMD)
                appendLog("[BONECO LENTO] ${result.output}")
                GrxOverlayService.stopOverlay(appContext)

                _uiState.update {
                    it.copy(
                        isBonecoLentoActive = false,
                        bonecoBannerVisible = false,
                        isBonecoBusy = false
                    )
                }
            }
        }
    }

    fun toggleFangrxShot(enable: Boolean) {
        if (_uiState.value.isFangrxBusy) return
        viewModelScope.launch {
            _uiState.update { it.copy(isFangrxBusy = true) }
            if (enable) {
                appendLog("[FANGRXSHOT] Executando pipeline completo via Shizuku AIDL...")
                val result = shizukuExecutor.execute(FANGRXSHOT_ON_CMD)
                appendLog("[FANGRXSHOT] Código saída: ${result.exitCode} | ${result.output}")
                _uiState.update {
                    it.copy(
                        isFangrxShotActive = true,
                        isFangrxBusy = false
                    )
                }
            } else {
                appendLog("[FANGRXSHOT] Executando reversão segura...")
                val result = shizukuExecutor.execute(FANGRXSHOT_OFF_CMD)
                appendLog("[FANGRXSHOT] Reversão código ${result.exitCode} | ${result.output}")
                _uiState.update {
                    it.copy(
                        isFangrxShotActive = false,
                        isFangrxBusy = false
                    )
                }
            }
        }
    }

    fun optimizeAllWithAiGrx() {
        if (_uiState.value.isOptimizingAll) return
        viewModelScope.launch {
            _uiState.update { it.copy(isOptimizingAll = true) }
            val beforeTelemetry = withContext(Dispatchers.IO) { readDeviceTelemetry() }
            appendLog(
                "[IA GRX] Analisando RAM (${beforeTelemetry.freeRamMb}/${beforeTelemetry.totalRamMb} MB) " +
                    "e Bateria (${String.format(Locale.US, "%.1f", beforeTelemetry.batteryTempCelsius)}°C)..."
            )

            val trimResult = shizukuExecutor.execute(AI_TRIM_CACHE_CMD)
            appendLog("[IA GRX] pm trim-caches 512M -> ${trimResult.output}")

            val bonecoResult = shizukuExecutor.execute(BONECO_LENTO_ON_CMD)
            appendLog("[IA GRX] Boneco Lento sincronizado -> exit=${bonecoResult.exitCode}")

            val fangrxResult = shizukuExecutor.execute(FANGRXSHOT_ON_CMD)
            appendLog("[IA GRX] FangrxShot sincronizado -> exit=${fangrxResult.exitCode}")

            val canDraw = runCatching { Settings.canDrawOverlays(appContext) }.getOrDefault(false)
            if (canDraw) {
                GrxOverlayService.startOverlay(appContext, _uiState.value.selectedCrosshairStyle)
            }

            val afterTelemetry = withContext(Dispatchers.IO) { readDeviceTelemetry() }
            val thermalStatus = when {
                afterTelemetry.batteryTempCelsius <= 0f -> "Sensor indisponível"
                afterTelemetry.batteryTempCelsius < 36f -> "Térmica Ideal"
                afterTelemetry.batteryTempCelsius < 41f -> "Carga Moderada"
                else -> "Temperatura Elevada — Foco em estabilidade"
            }

            val shizukuOk = trimResult.success || bonecoResult.success || fangrxResult.success
            val timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            val summary = if (shizukuOk) {
                "Boneco Lento + FangrxShot sincronizados e cache de 512M limpo via Shizuku AIDL."
            } else {
                "Perfis Boneco Lento e FangrxShot armados no painel. Conecte o Shizuku para aplicar comandos privilegiados no sistema."
            }

            _uiState.update {
                it.copy(
                    isBonecoLentoActive = true,
                    isFangrxShotActive = true,
                    bonecoBannerVisible = true,
                    hasOverlayPermission = canDraw,
                    isOptimizingAll = false,
                    telemetry = afterTelemetry,
                    aiReport = AiOptimizationReport(
                        timestamp = timestamp,
                        freeRamBeforeMb = beforeTelemetry.freeRamMb,
                        freeRamAfterMb = afterTelemetry.freeRamMb,
                        totalRamMb = afterTelemetry.totalRamMb,
                        batteryTempCelsius = afterTelemetry.batteryTempCelsius,
                        thermalStatusText = thermalStatus,
                        shizukuExecuted = shizukuOk,
                        summary = summary
                    )
                )
            }
        }
    }

    private fun readDeviceTelemetry(): DeviceTelemetry {
        val memoryInfo = ActivityManager.MemoryInfo()
        runCatching {
            val am = appContext.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            am?.getMemoryInfo(memoryInfo)
        }
        val freeMb = memoryInfo.availMem / (1024L * 1024L)
        val totalMb = memoryInfo.totalMem / (1024L * 1024L)

        val batteryTemp = runCatching {
            val intent = appContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val tenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
            tenths / 10f
        }.getOrDefault(0f)

        return DeviceTelemetry(
            freeRamMb = freeMb,
            totalRamMb = totalMb,
            batteryTempCelsius = batteryTemp,
            lowMemory = memoryInfo.lowMemory
        )
    }

    private fun appendLog(entry: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        _uiState.update { state ->
            val updated = (state.terminalLogs + "[$time] $entry").takeLast(40)
            state.copy(terminalLogs = updated)
        }
    }
}
