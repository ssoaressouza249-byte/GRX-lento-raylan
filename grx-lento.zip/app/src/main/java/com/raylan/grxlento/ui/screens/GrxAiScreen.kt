package com.raylan.grxlento.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.grxlento.R
import com.raylan.grxlento.ui.AiOptimizationReport
import com.raylan.grxlento.ui.GrxUiState
import com.raylan.grxlento.ui.theme.DeepBlack
import com.raylan.grxlento.ui.theme.FireOrange
import com.raylan.grxlento.ui.theme.MetallicNavy
import com.raylan.grxlento.ui.theme.MetallicNavyVariant
import com.raylan.grxlento.ui.theme.NeonCyan
import com.raylan.grxlento.ui.theme.NeonGreen
import com.raylan.grxlento.ui.theme.TerminalBlack
import com.raylan.grxlento.ui.theme.TextPrimary
import com.raylan.grxlento.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun GrxAiScreen(
    state: GrxUiState,
    onOptimizeAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DeepBlack),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                GojoRaylanHeroBanner()
            }

            item {
                AiOptimizerControlCard(
                    state = state,
                    onOptimizeAll = onOptimizeAll
                )
            }

            item {
                AnimatedVisibility(visible = state.aiReport != null) {
                    state.aiReport?.let { report ->
                        AiOptimizationReportCard(report = report)
                    }
                }
            }

            item {
                OfficialCreatorCard()
            }

            item {
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }
}

@Composable
private fun GojoRaylanHeroBanner() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(20.dp))
            .border(
                width = 2.dp,
                brush = Brush.linearGradient(
                    colors = listOf(NeonCyan, Color(0xFF0091EA), NeonCyan)
                ),
                shape = RoundedCornerShape(20.dp)
            )
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_gojo_raylan_ai),
            contentDescription = "Arte IA Raylan com energia azul neon",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color(0x4407080D),
                            Color(0xE607080D)
                        )
                    )
                )
        )

        Row(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SISTEMA IA GRX • RAYLAN",
                    color = NeonCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.1.sp
                )
                Text(
                    text = "Motor de Otimização Inteligente",
                    color = TextPrimary,
                    style = MaterialTheme.typography.titleLarge
                )
            }

            Surface(
                color = FireOrange.copy(alpha = 0.2f),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, FireOrange)
            ) {
                Text(
                    text = "RAYLAN IA",
                    color = FireOrange,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun AiOptimizerControlCard(
    state: GrxUiState,
    onOptimizeAll: () -> Unit
) {
    val freeGb = state.telemetry.freeRamMb / 1024f
    val totalGb = state.telemetry.totalRamMb / 1024f
    val tempStr = if (state.telemetry.batteryTempCelsius > 0f) {
        String.format(Locale.US, "%.1f °C", state.telemetry.batteryTempCelsius)
    } else {
        "N/D"
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MetallicNavy),
        border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.7f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "OTIMIZADOR AUTOMÁTICO IA GRX",
                color = TextPrimary,
                style = MaterialTheme.typography.titleLarge
            )

            Text(
                text = "Analisa RAM livre e temperatura da bateria, limpa caches do sistema (512M) e sincroniza Boneco Lento + FangrxShot em um toque.",
                color = TextSecondary,
                style = MaterialTheme.typography.bodyMedium
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TelemetryMetricPill(
                    icon = Icons.Filled.Memory,
                    label = "RAM LIVRE",
                    value = String.format(Locale.US, "%.1f / %.1f GB", freeGb, totalGb),
                    accentColor = NeonCyan,
                    modifier = Modifier.weight(1f)
                )
                TelemetryMetricPill(
                    icon = Icons.Filled.Thermostat,
                    label = "BATERIA",
                    value = tempStr,
                    accentColor = FireOrange,
                    modifier = Modifier.weight(1f)
                )
            }

            Button(
                onClick = onOptimizeAll,
                enabled = !state.isOptimizingAll,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 56.dp)
                    .testTag("btn_optimize_all_ai"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonCyan,
                    contentColor = DeepBlack,
                    disabledContainerColor = MetallicNavyVariant,
                    disabledContentColor = NeonCyan
                )
            ) {
                if (state.isOptimizingAll) {
                    CircularProgressIndicator(
                        color = NeonCyan,
                        strokeWidth = 2.5.dp,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "ANALISANDO E SINCRONIZANDO...",
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = stringResource(R.string.ai_optimize_button),
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        letterSpacing = 0.6.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun TelemetryMetricPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .background(TerminalBlack, RoundedCornerShape(12.dp))
            .border(1.dp, accentColor.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(20.dp)
        )
        Column {
            Text(
                text = label,
                color = TextSecondary,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = value,
                color = TextPrimary,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.ExtraBold
            )
        }
    }
}

@Composable
private fun AiOptimizationReportCard(report: AiOptimizationReport) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ai_optimization_report"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MetallicNavyVariant),
        border = BorderStroke(1.dp, NeonGreen.copy(alpha = 0.7f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Verified,
                    contentDescription = null,
                    tint = NeonGreen,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "DIAGNÓSTICO IA GRX • ${report.timestamp}",
                    color = NeonGreen,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            Text(
                text = report.summary,
                color = TextPrimary,
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = "RAM: ${report.freeRamBeforeMb}MB -> ${report.freeRamAfterMb}MB | " +
                    "Térmica: ${report.thermalStatusText}",
                color = NeonCyan,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun OfficialCreatorCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MetallicNavy),
        border = BorderStroke(
            width = 1.dp,
            brush = Brush.horizontalGradient(listOf(FireOrange, NeonCyan))
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(FireOrange.copy(alpha = 0.14f), RoundedCornerShape(12.dp))
                    .border(1.dp, FireOrange, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Shield,
                    contentDescription = "Selo oficial do criador",
                    tint = FireOrange,
                    modifier = Modifier.size(24.dp)
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = stringResource(R.string.creator_credits),
                    color = FireOrange,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = stringResource(R.string.creator_card_message),
                    color = TextPrimary,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
