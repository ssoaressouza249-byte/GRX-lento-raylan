package com.raylan.grxlento.overlay

enum class CrosshairStyle(val label: String) {
    VERTICAL_GUIDE("Guia Vertical"),
    PRO_RING("Anel Pro"),
    CENTER_DOT("Ponto Central")
}
