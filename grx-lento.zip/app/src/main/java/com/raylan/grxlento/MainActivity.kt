package com.raylan.grxlento

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.raylan.grxlento.security.SecurityGuard
import com.raylan.grxlento.security.TamperCheckResult
import com.raylan.grxlento.security.TamperLockScreen
import com.raylan.grxlento.ui.GrxMainViewModel
import com.raylan.grxlento.ui.screens.GrxAiScreen
import com.raylan.grxlento.ui.screens.GrxControlScreen
import com.raylan.grxlento.ui.theme.DeepBlack
import com.raylan.grxlento.ui.theme.MetallicNavy
import com.raylan.grxlento.ui.theme.MetallicNavyVariant
import com.raylan.grxlento.ui.theme.NeonCyan
import com.raylan.grxlento.ui.theme.TextSecondary
import com.raylan.grxlento.ui.theme.GrxLentoTheme

class MainActivity : ComponentActivity() {

    private var tamperState by mutableStateOf(TamperCheckResult(isAuthentic = true))
    private var mainViewModel: GrxMainViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        runCatching { enableEdgeToEdge() }

        tamperState = SecurityGuard.verifyAppIntegrity(this)

        setContent {
            GrxLentoTheme {
                if (!tamperState.isAuthentic) {
                    TamperLockScreen(reasons = tamperState.reasons)
                } else {
                    val vm: GrxMainViewModel = viewModel()
                    mainViewModel = vm
                    GrxLentoApp(viewModel = vm)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tamperState = SecurityGuard.verifyAppIntegrity(this)
        if (tamperState.isAuthentic) {
            runCatching { mainViewModel?.refreshSystemStatus() }
        }
    }
}

@Composable
private fun GrxLentoApp(viewModel: GrxMainViewModel) {
    val context = LocalContext.current
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = runCatching {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            }.getOrDefault(true)
            if (!granted) {
                runCatching {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        }
    }

    val isExpandedScreen = LocalConfiguration.current.screenWidthDp >= 600
    val tabs = listOf(
        stringResource(R.string.tab_grx_functions),
        stringResource(R.string.tab_ai_raylan)
    )

    if (isExpandedScreen) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .background(DeepBlack)
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            NavigationRail(
                containerColor = MetallicNavy,
                modifier = Modifier.fillMaxHeight()
            ) {
                tabs.forEachIndexed { index, title ->
                    val isSelected = selectedTab == index
                    NavigationRailItem(
                        selected = isSelected,
                        onClick = { selectedTab = index },
                        modifier = Modifier.testTag("nav_tab_$index"),
                        icon = {
                            Icon(
                                imageVector = when (index) {
                                    0 -> if (isSelected) Icons.Filled.Tune else Icons.Outlined.Tune
                                    else -> if (isSelected) Icons.Filled.AutoAwesome else Icons.Outlined.AutoAwesome
                                },
                                contentDescription = title
                            )
                        },
                        label = {
                            Text(
                                text = title,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        colors = NavigationRailItemDefaults.colors(
                            selectedIconColor = NeonCyan,
                            selectedTextColor = NeonCyan,
                            indicatorColor = MetallicNavyVariant,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )
                }
            }

            Box(modifier = Modifier.weight(1f)) {
                TabContent(
                    selectedTab = selectedTab,
                    state = state,
                    viewModel = viewModel
                )
            }
        }
    } else {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = DeepBlack,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                NavigationBar(
                    containerColor = MetallicNavy,
                    tonalElevation = 0.dp,
                    windowInsets = WindowInsets.navigationBars
                ) {
                    tabs.forEachIndexed { index, title ->
                        val isSelected = selectedTab == index
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { selectedTab = index },
                            modifier = Modifier.testTag("nav_tab_$index"),
                            icon = {
                                Icon(
                                    imageVector = when (index) {
                                        0 -> if (isSelected) Icons.Filled.Tune else Icons.Outlined.Tune
                                        else -> if (isSelected) Icons.Filled.AutoAwesome else Icons.Outlined.AutoAwesome
                                    },
                                    contentDescription = title
                                )
                            },
                            label = {
                                Text(
                                    text = title,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = NeonCyan,
                                selectedTextColor = NeonCyan,
                                indicatorColor = MetallicNavyVariant,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                TabContent(
                    selectedTab = selectedTab,
                    state = state,
                    viewModel = viewModel
                )
            }
        }
    }
}

@Composable
private fun TabContent(
    selectedTab: Int,
    state: com.raylan.grxlento.ui.GrxUiState,
    viewModel: GrxMainViewModel
) {
    when (selectedTab) {
        0 -> GrxControlScreen(
            state = state,
            onConnectShizuku = viewModel::connectShizuku,
            onToggleBonecoLento = viewModel::toggleBonecoLento,
            onToggleFangrxShot = viewModel::toggleFangrxShot,
            onSelectCrosshairStyle = viewModel::selectCrosshairStyle,
            onToggleOverlayManual = viewModel::toggleOverlayManually,
            onClearLogs = viewModel::clearLogs
        )

        else -> GrxAiScreen(
            state = state,
            onOptimizeAll = viewModel::optimizeAllWithAiGrx
        )
    }
}
