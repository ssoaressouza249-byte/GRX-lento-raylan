package com.raylan.grxlento.security

import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import com.raylan.grxlento.R

data class TamperCheckResult(
    val isAuthentic: Boolean,
    val reasons: List<String> = emptyList()
)

object SecurityGuard {

    private const val EXPECTED_PACKAGE = "com.raylan.grxlento"
    private const val EXPECTED_APP_NAME = "GRX LENTO"
    private const val EXPECTED_MAIN_ACTIVITY = "com.raylan.grxlento.MainActivity"
    private const val EXPECTED_OVERLAY_SERVICE = "com.raylan.grxlento.overlay.GrxOverlayService"
    private const val EXPECTED_SHIZUKU_PROVIDER = "rikka.shizuku.ShizukuProvider"

    fun verifyAppIntegrity(context: Context): TamperCheckResult {
        val reasons = mutableListOf<String>()

        runCatching {
            if (context.packageName != EXPECTED_PACKAGE) {
                reasons += "Pacote alterado (${context.packageName})"
            }
        }.onFailure {
            reasons += "Falha ao validar pacote"
        }

        runCatching {
            val stringName = context.getString(R.string.app_name)
            if (stringName != EXPECTED_APP_NAME) {
                reasons += "Nome do recurso alterado ($stringName)"
            }
        }.onFailure {
            reasons += "Falha ao validar R.string.app_name"
        }

        runCatching {
            val pm = context.packageManager
            val label = context.applicationInfo.loadLabel(pm)?.toString().orEmpty()
            if (label != EXPECTED_APP_NAME) {
                reasons += "Rótulo visível alterado ($label)"
            }
        }.onFailure {
            reasons += "Falha ao validar ApplicationInfo.loadLabel"
        }

        runCatching {
            val packageInfo = getPackageInfoWithComponents(context)
            val hasMainActivity = packageInfo.activities?.any {
                it.name == EXPECTED_MAIN_ACTIVITY
            } == true
            val hasOverlayService = packageInfo.services?.any {
                it.name == EXPECTED_OVERLAY_SERVICE
            } == true
            val hasShizukuProvider = packageInfo.providers?.any {
                it.name == EXPECTED_SHIZUKU_PROVIDER
            } == true

            if (!hasMainActivity) {
                reasons += "MainActivity ausente ou alterada no manifesto"
            }
            if (!hasOverlayService) {
                reasons += "GrxOverlayService ausente ou alterado no manifesto"
            }
            if (!hasShizukuProvider) {
                reasons += "ShizukuProvider ausente ou alterado no manifesto"
            }
        }.onFailure {
            reasons += "Falha ao inspecionar componentes do manifesto"
        }

        return TamperCheckResult(
            isAuthentic = reasons.isEmpty(),
            reasons = reasons
        )
    }

    fun triggerUninstall(context: Context) {
        runCatching {
            val deleteIntent = Intent(Intent.ACTION_DELETE).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(deleteIntent)
        }
    }

    @Suppress("DEPRECATION")
    private fun getPackageInfoWithComponents(context: Context): PackageInfo {
        val pm = context.packageManager
        val flags = PackageManager.GET_ACTIVITIES or
            PackageManager.GET_SERVICES or
            PackageManager.GET_PROVIDERS
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getPackageInfo(
                context.packageName,
                PackageManager.PackageInfoFlags.of(flags.toLong())
            )
        } else {
            pm.getPackageInfo(context.packageName, flags)
        }
    }
}
