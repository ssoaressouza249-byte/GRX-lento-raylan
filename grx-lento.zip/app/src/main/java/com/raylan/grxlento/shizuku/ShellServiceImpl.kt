package com.raylan.grxlento.shizuku

import com.raylan.grxlento.IShellService
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit
import kotlin.system.exitProcess

class ShellServiceImpl : IShellService.Stub() {

    override fun execCommand(command: String?): String {
        val safeCommand = command?.trim().orEmpty()
        if (safeCommand.isEmpty()) {
            return "EXIT:1\nComando vazio."
        }

        return runCatching {
            val process = ProcessBuilder("sh", "-c", safeCommand)
                .redirectErrorStream(true)
                .start()

            val outputBuilder = StringBuilder()
            BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                var line = reader.readLine()
                while (line != null) {
                    outputBuilder.appendLine(line)
                    line = reader.readLine()
                }
            }

            val finished = process.waitFor(15, TimeUnit.SECONDS)
            val exitCode = if (finished) {
                process.exitValue()
            } else {
                process.destroyForcibly()
                -1
            }

            val rawOutput = outputBuilder.toString().trim()
            if (rawOutput.isEmpty()) {
                "EXIT:$exitCode\nOK (código $exitCode)"
            } else {
                "EXIT:$exitCode\n$rawOutput"
            }
        }.getOrElse { error ->
            "EXIT:-1\nErro de execução: ${error.message ?: "desconhecido"}"
        }
    }

    override fun destroy() {
        runCatching { exitProcess(0) }
    }
}
