package com.raylan.grxlento.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.grxlento.R
import com.raylan.grxlento.overlay.CrosshairStyle
import com.raylan.grxlento.shizuku.ShizukuConnectionState
import com.raylan.grxlento.ui.GrxUiState
import com.raylan.grxlento.ui.theme.BorderSubtle
import com.raylan.grxlento.ui.theme.CriticalRed
import com.raylan.grxlento.ui.theme.DeepBlack
import com.raylan.grxlento.ui.theme.FireOrange
import com.raylan.grxlento.ui.theme.MetallicNavy
import com.raylan.grxlento.ui.theme.MetallicNavyVariant
import com.raylan.grxlento.ui.theme.NeonCyan
import com.raylan.grxlento.ui.theme.NeonGreen
import com.raylan.grxlento.ui.theme.TerminalBlack
import com.raylan.grxlento.ui.theme.TextPrimary
import com.raylan.grxlento.ui.theme.TextSecondary

@Composable
fun GrxControlScreen(
    state: GrxUiState,
    onConnectShizuku: () -> Unit,
    onToggleBonecoLento: (Boolean) -> Unit,
    onToggleFangrxShot: (Boolean) -> Unit,
    onSelectCrosshairStyle: (CrosshairStyle) -> Unit,
    onToggleOverlayManual: () -> Unit,
    onClearLogs: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val terminalListState = rememberLazyListState()

    LaunchedEffect(state.terminalLogs.size) {
        if (state.terminalLogs.isNotEmpty()) {
            terminalListState.animateScrollToItem(state.terminalLogs.lastIndex)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DeepBlack),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                OfficialHeaderCard(
                    shizukuState = state.shizukuState,
                    onConnectShizuku = onConnectShizuku
                )
            }

            item {
                AnimatedVisibility(
                    visible = state.bonecoBannerVisible,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                brush = Brush.horizontalGradient(
                                    colors = listOf(
                                        Color(0xFF06291A),
                                        Color(0xFF281607)
                                    )
                                ),
                                shape = RoundedCornerShape(14.dp)
                            )
                            .border(
                                width = 1.dp,
                                brush = Brush.horizontalGradient(
                                    colors = listOf(NeonGreen, FireOrange)
                                ),
                                shape = RoundedCornerShape(14.dp)
                            )
                            .padding(horizontal = 14.dp, vertical = 12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Verified,
                                contentDescription = null,
                                tint = NeonGreen,
                                modifier = Modifier.size(22.dp)
                            )
                            Text(
                                text = stringResource(R.string.boneco_lento_banner),
                                color = TextPrimary,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            item {
                BonecoLentoModuleCard(
                    isActive = state.isBonecoLentoActive,
                    isBusy = state.isBonecoBusy,
                    onToggle = onToggleBonecoLento
                )
            }

            item {
                FangrxShotModuleCard(
                    isActive = state.isFangrxShotActive,
                    isBusy = state.isFangrxBusy,
                    terminalLogs = state.terminalLogs,
                    terminalListState = terminalListState,
                    onToggle = onToggleFangrxShot,
                    onClearLogs = onClearLogs
                )
            }

            item {
                FloatingCrosshairControlCard(
                    hasPermission = state.hasOverlayPermission,
                    isOverlayActive = state.isOverlayActive,
                    selectedStyle = state.selectedCrosshairStyle,
                    onRequestPermission = {
                        runCatching {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            ).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        }
                    },
                    onSelectStyle = onSelectCrosshairStyle,
                    onToggleOverlay = onToggleOverlayManual
                )
            }

            item {
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }
}

@Composable
private fun OfficialHeaderCard(
    shizukuState: ShizukuConnectionState,
    onConnectShizuku: () -> Unit
) {
    val isReady = shizukuState.isReady
    val chipColor = if (isReady) NeonGreen else FireOrange
    val chipText = if (isReady) {
        stringResource(R.string.shizuku_ready)
    } else {
        stringResource(R.string.shizuku_connect)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MetallicNavy),
        border = BorderStroke(
            width = 1.dp,
            brush = Brush.horizontalGradient(listOf(NeonCyan, FireOrange.copy(alpha = 0.7f)))
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.app_name),
                            color = TextPrimary,
                            style = MaterialTheme.typography.headlineLarge
                        )
                        Surface(
                            color = FireOrange.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, FireOrange.copy(alpha = 0.7f))
                        ) {
                            Text(
                                text = stringResource(R.string.creator_badge),
                                color = FireOrange,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = stringResource(R.string.creator_credits),
                        color = NeonCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Surface(
                    onClick = onConnectShizuku,
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .testTag("shizuku_status_chip"),
                    shape = RoundedCornerShape(12.dp),
                    color = chipColor.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, chipColor)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Link,
                            contentDescription = "Status do Shizuku",
                            tint = chipColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = chipText,
                            color = chipColor,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            val detailMessage = when (shizukuState) {
                is ShizukuConnectionState.Ready -> shizukuState.message
                is ShizukuConnectionState.Connecting -> shizukuState.message
                is ShizukuConnectionState.PermissionRequired -> shizukuState.message
                is ShizukuConnectionState.Disconnected -> shizukuState.message
                is ShizukuConnectionState.Error -> shizukuState.message
            }
            Text(
                text = "Shizuku AIDL: $detailMessage",
                color = TextSecondary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun BonecoLentoModuleCard(
    isActive: Boolean,
    isBusy: Boolean,
    onToggle: (Boolean) -> Unit
) {
    val statusColor = if (isActive) NeonGreen else CriticalRed
    val statusLabel = if (isActive) {
        stringResource(R.string.status_active)
    } else {
        stringResource(R.string.status_inactive)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MetallicNavy),
        border = BorderStroke(
            width = 1.dp,
            color = if (isActive) NeonGreen else NeonCyan.copy(alpha = 0.65f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .background(NeonCyan.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                            .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.TouchApp,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column {
                        Text(
                            text = stringResource(R.string.boneco_lento_title),
                            color = TextPrimary,
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = statusLabel,
                            color = statusColor,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.testTag("status_boneco_lento")
                        )
                    }
                }

                if (isBusy) {
                    CircularProgressIndicator(
                        color = NeonCyan,
                        strokeWidth = 2.5.dp,
                        modifier = Modifier.size(28.dp)
                    )
                } else {
                    Switch(
                        checked = isActive,
                        onCheckedChange = onToggle,
                        modifier = Modifier.testTag("switch_boneco_lento"),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = DeepBlack,
                            checkedTrackColor = NeonGreen,
                            uncheckedThumbColor = TextSecondary,
                            uncheckedTrackColor = MetallicNavyVariant,
                            uncheckedBorderColor = BorderSubtle
                        )
                    )
                }
            }

            Text(
                text = stringResource(R.string.boneco_lento_subtitle),
                color = TextSecondary,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun FangrxShotModuleCard(
    isActive: Boolean,
    isBusy: Boolean,
    terminalLogs: List<String>,
    terminalListState: androidx.compose.foundation.lazy.LazyListState,
    onToggle: (Boolean) -> Unit,
    onClearLogs: () -> Unit
) {
    val statusColor = if (isActive) NeonGreen else CriticalRed
    val statusLabel = if (isActive) {
        stringResource(R.string.status_active)
    } else {
        stringResource(R.string.status_inactive)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MetallicNavy),
        border = BorderStroke(
            width = 1.dp,
            color = if (isActive) FireOrange else NeonCyan.copy(alpha = 0.65f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .background(FireOrange.copy(alpha = 0.14f), RoundedCornerShape(12.dp))
                            .border(1.dp, FireOrange.copy(alpha = 0.6f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Bolt,
                            contentDescription = null,
                            tint = FireOrange,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column {
                        Text(
                            text = stringResource(R.string.fangrxshot_title),
                            color = TextPrimary,
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = statusLabel,
                            color = statusColor,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.testTag("status_fangrxshot")
                        )
                    }
                }

                if (isBusy) {
                    CircularProgressIndicator(
                        color = FireOrange,
                        strokeWidth = 2.5.dp,
                        modifier = Modifier.size(28.dp)
                    )
                } else {
                    Switch(
                        checked = isActive,
                        onCheckedChange = onToggle,
                        modifier = Modifier.testTag("switch_fangrxshot"),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = DeepBlack,
                            checkedTrackColor = NeonGreen,
                            uncheckedThumbColor = TextSecondary,
                            uncheckedTrackColor = MetallicNavyVariant,
                            uncheckedBorderColor = BorderSubtle
                        )
                    )
                }
            }

            Text(
                text = stringResource(R.string.fangrxshot_subtitle),
                color = TextSecondary,
                style = MaterialTheme.typography.bodyMedium
            )

            // Mini-terminal Shizuku em tempo real
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalBlack, RoundedCornerShape(12.dp))
                    .border(1.dp, NeonCyan.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Terminal,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = stringResource(R.string.terminal_title),
                            color = NeonCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    IconButton(
                        onClick = onClearLogs,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("btn_clear_terminal")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteSweep,
                            contentDescription = "Limpar terminal",
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    state = terminalListState,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(112.dp)
                        .testTag("shizuku_mini_terminal"),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(terminalLogs) { line ->
                        val lineColor = when {
                            line.contains("ERRO", ignoreCase = true) ||
                                line.contains("EXCEÇÃO", ignoreCase = true) -> CriticalRed
                            line.contains("PERMISSÃO", ignoreCase = true) -> FireOrange
                            line.contains("OK", ignoreCase = true) ||
                                line.contains("exit=0", ignoreCase = true) ||
                                line.contains("código 0", ignoreCase = true) -> NeonGreen
                            else -> Color(0xFFB7F6FF)
                        }
                        Text(
                            text = line,
                            color = lineColor,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FloatingCrosshairControlCard(
    hasPermission: Boolean,
    isOverlayActive: Boolean,
    selectedStyle: CrosshairStyle,
    onRequestPermission: () -> Unit,
    onSelectStyle: (CrosshairStyle) -> Unit,
    onToggleOverlay: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MetallicNavy),
        border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.55f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(NeonCyan.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                            .border(1.dp, NeonCyan.copy(alpha = 0.45f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CenterFocusStrong,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column {
                        Text(
                            text = stringResource(R.string.overlay_card_title),
                            color = TextPrimary,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = if (isOverlayActive) "Mira Visível na Tela" else "Mira Oculta",
                            color = if (isOverlayActive) NeonGreen else TextSecondary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                CrosshairPreviewBadge(style = selectedStyle)
            }

            // Seletor de estilo da mira
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CrosshairStyle.entries.forEach { style ->
                    val isSelected = style == selectedStyle
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isSelected) NeonCyan.copy(alpha = 0.16f) else MetallicNavyVariant
                            )
                            .border(
                                width = 1.dp,
                                color = if (isSelected) NeonCyan else BorderSubtle,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { onSelectStyle(style) }
                            .padding(horizontal = 8.dp, vertical = 10.dp)
                            .testTag("style_chip_${style.name.lowercase()}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = style.label,
                            color = if (isSelected) NeonCyan else TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            if (!hasPermission) {
                Button(
                    onClick = onRequestPermission,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("btn_overlay_permission"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = FireOrange,
                        contentColor = DeepBlack
                    )
                ) {
                    Icon(
                        imageVector = Icons.Filled.Layers,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.overlay_permission_grant),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp
                    )
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onRequestPermission,
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("btn_overlay_settings"),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, NeonGreen.copy(alpha = 0.6f))
                    ) {
                        Text(
                            text = stringResource(R.string.overlay_permission_ok),
                            color = NeonGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Button(
                        onClick = onToggleOverlay,
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("btn_toggle_overlay"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isOverlayActive) CriticalRed else NeonCyan,
                            contentColor = if (isOverlayActive) Color.White else DeepBlack
                        )
                    ) {
                        Text(
                            text = if (isOverlayActive) "Desligar Mira" else "Ativar Mira",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CrosshairPreviewBadge(style: CrosshairStyle) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .background(TerminalBlack, CircleShape)
            .border(1.dp, NeonCyan.copy(alpha = 0.5f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(28.dp)) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            when (style) {
                CrosshairStyle.VERTICAL_GUIDE -> {
                    drawLine(
                        color = NeonCyan,
                        start = Offset(cx, 2f),
                        end = Offset(cx, size.height - 2f),
                        strokeWidth = 2.5f,
                        cap = StrokeCap.Round
                    )
                    drawLine(
                        color = NeonCyan,
                        start = Offset(cx - 5f, cy - 6f),
                        end = Offset(cx + 5f, cy - 6f),
                        strokeWidth = 2f
                    )
                    drawCircle(color = FireOrange, radius = 3.2f, center = Offset(cx, cy))
                }
                CrosshairStyle.PRO_RING -> {
                    drawCircle(
                        color = NeonCyan,
                        radius = 8.5f,
                        center = Offset(cx, cy),
                        style = Stroke(width = 2.2f)
                    )
                    drawCircle(color = FireOrange, radius = 2.8f, center = Offset(cx, cy))
                }
                CrosshairStyle.CENTER_DOT -> {
                    drawCircle(color = NeonCyan, radius = 4.5f, center = Offset(cx, cy))
                    drawCircle(color = FireOrange, radius = 2.2f, center = Offset(cx, cy))
                }
            }
        }
    }
}
