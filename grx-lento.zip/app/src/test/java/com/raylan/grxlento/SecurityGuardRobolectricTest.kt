package com.raylan.grxlento

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.raylan.grxlento.security.SecurityGuard
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SecurityGuardRobolectricTest {

    @Test
    fun `app name and integrity check pass for official package`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("GRX LENTO", context.getString(R.string.app_name))
        val result = SecurityGuard.verifyAppIntegrity(context)
        assertTrue("Expected authentic app, reasons=${result.reasons}", result.isAuthentic)
    }
}
